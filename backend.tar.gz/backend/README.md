# 🎓 Alatoo University LMS - Backend API

Полноценный Backend API для системы управления обучением Alatoo University.

## 📋 Технологии

- **Node.js** + **Express** - веб-сервер
- **PostgreSQL** - база данных
- **JWT** - аутентификация
- **bcryptjs** - хеширование паролей
- **express-validator** - валидация данных

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
npm install
```

### 2. Настройка базы данных

Установите PostgreSQL:

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
```

**macOS (через Homebrew):**
```bash
brew install postgresql
brew services start postgresql
```

**Windows:**
Скачайте с [postgresql.org](https://www.postgresql.org/download/windows/)

### 3. Создание базы данных

```bash
# Войдите в PostgreSQL
sudo -u postgres psql

# Создайте базу данных
CREATE DATABASE alatoo_lms;

# Создайте пользователя (опционально)
CREATE USER alatoo_admin WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE alatoo_lms TO alatoo_admin;

# Выйдите
\q
```

### 4. Создание таблиц

```bash
# Примените схему
psql -U postgres -d alatoo_lms -f database/schema.sql

# Или если создали пользователя:
psql -U alatoo_admin -d alatoo_lms -f database/schema.sql
```

### 5. Настройка переменных окружения

```bash
# Скопируйте пример файла
cp .env.example .env

# Отредактируйте .env файл
nano .env
```

Измените следующие параметры:
```env
DB_PASSWORD=your_actual_password
JWT_SECRET=your_very_long_and_secure_random_string_here
```

### 6. Заполнение тестовыми данными

```bash
npm run seed
```

Это создаст:
- 4 тестовых аккаунта (2 студента, 1 преподаватель, 1 админ)
- Экзамены
- Оценки
- Расписание
- Объявления

### 7. Запуск сервера

**Разработка (с автоперезагрузкой):**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

Сервер запустится на `http://localhost:5000`

## 🔐 Тестовые аккаунты

| Роль | Email | Пароль | Student ID |
|------|-------|--------|------------|
| Студент 1 | azamat@alatoo.edu.kg | 1234 | 240145121 |
| Студент 2 | aizhan@alatoo.edu.kg | 1234 | 240145122 |
| Преподаватель | maria@alatoo.edu.kg | 5678 | - |
| Админ | admin@alatoo.edu.kg | admin | - |

## 📡 API Endpoints

### Аутентификация

```http
POST /api/auth/register     # Регистрация
POST /api/auth/login        # Вход
GET  /api/auth/me           # Текущий пользователь
PUT  /api/auth/password     # Изменить пароль
```

### Пользователи

```http
GET  /api/users             # Все пользователи (admin)
GET  /api/users/:id         # Профиль пользователя
PUT  /api/users/:id         # Обновить профиль
```

### Экзамены

```http
GET  /api/exams             # Получить экзамены
POST /api/exams             # Создать экзамен (teacher/admin)
PUT  /api/exams/:id         # Обновить экзамен
DELETE /api/exams/:id       # Удалить экзамен
```

### Оценки

```http
POST /api/grades                    # Выставить оценку (teacher/admin)
GET  /api/grades/student/:studentId # Оценки студента
GET  /api/grades/stats/:studentId   # Статистика студента
```

### Расписание

```http
GET  /api/schedule          # Получить расписание
POST /api/schedule          # Создать занятие (teacher/admin)
PUT  /api/schedule/:id      # Обновить занятие
DELETE /api/schedule/:id    # Удалить занятие
```

### Домашние задания

```http
GET  /api/assignments       # Получить задания
POST /api/assignments       # Создать задание (teacher/admin)
```

### Посещаемость

```http
POST /api/attendance                    # Отметить посещение (teacher/admin)
GET  /api/attendance/student/:studentId # Посещаемость студента
```

### Объявления

```http
GET  /api/announcements     # Получить объявления
POST /api/announcements     # Создать объявление (teacher/admin)
DELETE /api/announcements/:id # Удалить объявление
```

## 🔑 Аутентификация

Все защищенные endpoints требуют JWT токен в header:

```http
Authorization: Bearer YOUR_JWT_TOKEN
```

### Пример использования

**1. Вход:**
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"login":"azamat@alatoo.edu.kg","password":"1234"}'
```

**Ответ:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "email": "azamat@alatoo.edu.kg",
    "name": "Азамат Студентов",
    "role": "student",
    "studentId": "240145121"
  }
}
```

**2. Использование токена:**
```bash
curl http://localhost:5000/api/exams \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIs..."
```

## 📦 Структура проекта

```
backend/
├── config/
│   └── database.js          # Конфигурация БД
├── database/
│   └── schema.sql           # SQL схема
├── middleware/
│   └── auth.js              # Middleware аутентификации
├── routes/
│   ├── auth.js              # Роуты аутентификации
│   ├── users.js             # Роуты пользователей
│   ├── exams.js             # Роуты экзаменов
│   ├── grades.js            # Роуты оценок
│   ├── schedule.js          # Роуты расписания
│   ├── assignments.js       # Роуты заданий
│   ├── attendance.js        # Роуты посещаемости
│   └── announcements.js     # Роуты объявлений
├── seeds/
│   └── seed.js              # Тестовые данные
├── uploads/                 # Загруженные файлы
├── .env.example             # Пример конфигурации
├── package.json
├── server.js                # Главный файл сервера
└── README.md
```

## 🔒 Безопасность

- ✅ JWT токены с истечением срока
- ✅ Хеширование паролей с bcrypt
- ✅ Rate limiting (100 запросов / 15 минут)
- ✅ Helmet.js для HTTP заголовков
- ✅ CORS настройка
- ✅ SQL injection защита (parameterized queries)
- ✅ Валидация входных данных

## 🛠️ Разработка

### Просмотр логов

```bash
# Development режим показывает все запросы
npm run dev
```

### Подключение к базе данных

```bash
psql -U postgres -d alatoo_lms
```

### Полезные SQL команды

```sql
-- Посмотреть все таблицы
\dt

-- Посмотреть структуру таблицы
\d users

-- Посмотреть количество пользователей
SELECT COUNT(*) FROM users;

-- Посмотреть всех студентов
SELECT name, student_id, group_name FROM users WHERE role = 'student';
```

## 📊 База данных

### Основные таблицы

- **users** - Пользователи (студенты, преподаватели, админы)
- **exams** - Экзамены
- **grades** - Оценки
- **schedule** - Расписание занятий
- **assignments** - Домашние задания
- **assignment_submissions** - Сданные работы
- **attendance** - Посещаемость
- **announcements** - Объявления
- **courses** - Курсы (для будущего расширения)

## 🚀 Деплой в Production

### 1. Используйте environment variables

```bash
NODE_ENV=production
```

### 2. Используйте process manager (PM2)

```bash
npm install -g pm2
pm2 start server.js --name alatoo-api
pm2 save
pm2 startup
```

### 3. Настройте reverse proxy (Nginx)

```nginx
server {
    listen 80;
    server_name api.alatoo.edu.kg;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 4. Настройте SSL (Let's Encrypt)

```bash
sudo certbot --nginx -d api.alatoo.edu.kg
```

## 🔄 Обновление схемы БД

При добавлении новых таблиц:

```bash
# Создайте миграцию
psql -U postgres -d alatoo_lms -f database/new_migration.sql
```

## 🐛 Troubleshooting

### Проблема: "Database connection failed"

**Решение:**
1. Проверьте что PostgreSQL запущен: `sudo systemctl status postgresql`
2. Проверьте .env файл
3. Проверьте права доступа к базе данных

### Проблема: "Port 5000 already in use"

**Решение:**
Измените порт в .env файле или остановите другой процесс:
```bash
lsof -ti:5000 | xargs kill -9
```

### Проблема: "JWT token invalid"

**Решение:**
1. Проверьте что JWT_SECRET одинаковый
2. Токен мог истечь - войдите заново

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи: `npm run dev`
2. Проверьте базу данных
3. Убедитесь что все зависимости установлены

## 📝 Changelog

### v1.0.0 (2026-02-16)
- ✅ Базовая API структура
- ✅ Аутентификация с JWT
- ✅ CRUD для экзаменов
- ✅ Система оценок
- ✅ Расписание
- ✅ Посещаемость
- ✅ Объявления
- ✅ Домашние задания

## 🎯 Следующие шаги

1. Интегрируйте frontend с этим API
2. Добавьте загрузку файлов (multer)
3. Добавьте email уведомления
4. Добавьте WebSocket для real-time обновлений
5. Добавьте Redis для кеширования
6. Настройте Docker для легкого деплоя

---

Made with ❤️ for Alatoo University
